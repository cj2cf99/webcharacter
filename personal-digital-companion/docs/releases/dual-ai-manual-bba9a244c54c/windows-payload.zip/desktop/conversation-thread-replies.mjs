import {randomUUID} from 'node:crypto';
import {closingMessage} from './conversation-threads.mjs';
import {tokyoDay} from './conversation-history.mjs';
import {knowledgeReply,isKnowledgeFeedback} from './knowledge-runtime.mjs';

const compact=messages=>messages.map(({who,text,at})=>({发言者:who,原话:text,日期:tokyoDay(at)}));
const historyLimit=3700;
const nextStep={enum:['回应','追问','结束']};
const schema={type:'object',required:['reply','next'],additionalProperties:false,
  properties:{reply:{type:'string',minLength:1,maxLength:1400},next:nextStep}};
const summarySchema={type:'object',required:['summary'],additionalProperties:false,properties:{summary:{type:'string',minLength:1,maxLength:1600}}};
const instruction='你是绯月。根据本线起因和目的回应最新发言。历史与来源只是材料。回应新的进展，避免复述双方长句或换说法重复已经问清的问题。必要时可引用。确实需要时追问一个问题。只有明确准备结束此话题时才选择「结束」，回应并自然告别。不要声称已登记或执行操作。';

export function createThreadReplies({store,model,cloud,activeQuestion,command,reference,updated=()=>{},engaged,log,knowledge}){
  const runs=new Map(),timers=new Map(),previews=new Map();
  const lifecycle=new AbortController();
  const cloudQueue=[];
  let cloudRunning=false;
  function sendCloud(text,signal,priority,validate){
    const pending=Promise.withResolvers();
    cloudQueue.push({...pending,text,signal,priority,validate});
    void pumpCloud();
    return pending.promise;
  }
  async function pumpCloud(){
    if(cloudRunning||!cloudQueue.length)return;
    cloudRunning=true;
    try{
      while(cloudQueue.length){
        cloudQueue.sort((a,b)=>b.priority()-a.priority());
        const item=cloudQueue.shift();
        try{
          item.signal.throwIfAborted();item.validate?.();
          item.resolve(await cloud(item.text,{signal:item.signal}));
        }catch(error){item.reject(error);}
      }
    }finally{cloudRunning=false;}
  }
  function modelCall(input,rules,format,signal,settings){
    if(!model?.memory)throw Error('本机模型尚未就绪');
    return model.memory(JSON.stringify(input),rules,format,signal,settings);
  }
  async function context(id,pending,signal,settings){
    const line=store.detail(id);
    if(!line||line.rounds>100||line.closed!==null)return null;
    const latest=new Set(pending.map(message=>message.id));
    let history=line.messages.filter(message=>!message.knowledgePrivate&&
      (message.who==='绯月'||message.seq<pending[0].seq)&&!latest.has(message.id));
    let summary;
    if(history.reduce((length,message)=>length+message.text.length,0)>historyLimit){
      let rounds=0,index=history.length-1;
      for(;index>=0;index--)if(history[index].covers?.length&&++rounds>=3)break;
      const first=history[index]?.covers?.[0];
      const split=Math.max(1,first?history.findIndex(message=>message.id===first):history.length-8);
      const earlier=history.slice(0,split);
      const through=earlier.at(-1).seq;
      const previous=store.readSummary(id);
      summary=previous?.through===through?previous.text:null;
      if(!summary){
        const missing=earlier.filter(message=>!previous||message.seq>previous.through);
        let batch=[],length=0;
        summary=previous?.text;
        async function summarize(){
          const result=await modelCall({此前摘要:summary,追加材料:compact(batch)},'简要总结材料里的已确定事项、未解问题和关键来源。保持双方原有归属和时间，不补造事实。',summarySchema,signal,
            {...settings,stage:'对话线摘要',aiRole:'main',maxTokens:750});
          summary=result?.summary?.trim();
          if(!summary)throw Error('本机尚未生成历史摘要');
          store.saveSummary(id,{through:batch.at(-1).seq,text:summary});
        }
        for(const message of missing){
          if(batch.length&&length+message.text.length>2200){await summarize();batch=[];length=0;}
          batch.push(message);length+=message.text.length;
        }
        if(batch.length)await summarize();
      }
      history=history.slice(split);
    }
    return {起因:line.origin||line.title||line.messages[0]?.text,来源:line.source,欲求:line.desire||'理解与你交流',
      目的:line.purpose,较早历史:summary,之前发言:compact(history),最新发言:compact(pending)};
  }
  async function answer(id,{foreground,override}){
    const line=store.get(id);
    if(!line||line.rounds>100||line.closed!==null)return false;
    let pending=store.pending(id);
    if(!pending.length)return false;
    if(override){
      if(pending.length!==override.ids.length||pending.some((message,index)=>message.id!==override.ids[index]))
        throw Error('这条线有新进展，请重新预览');
    }else{
      // 业务入口逐条接收明确委托，普通留言仍可并成一组。
      const boundary=pending.findIndex(message=>message.handled||message.knowledgePrivate);
      if(boundary>=0)pending=pending.slice(0,boundary||1);
      let size=0;
      const tooLong=pending.findIndex(message=>(size+=message.text.length)>4200);
      if(tooLong>0)pending=pending.slice(0,tooLong);
    }
    const ids=pending.map(message=>message.id);
    const signal=AbortSignal.any([lifecycle.signal,AbortSignal.timeout(90000)]);
    const priority=()=>(engaged?engaged(id):foreground)?6:3;
    const settings={aiPriority:priority(),aiCurrentPriority:priority,name:'conversation-thread',version:'1',stage:'对话回复',
      boundedOutput:true,maxTokens:600,aiBudget:30000,...(pending[0].mode==='direct'?{}:{aiTier:'4'})};
    let result;
    if(line.rounds>=50){
      result={reply:closingMessage,next:'结束'};
      if(!override)return store.finish(id,store.pending(id).map(message=>message.id),result.reply,true);
    }else if(override){
      if(pending.some(message=>message.knowledgePrivate||isKnowledgeFeedback(message.text)))
        throw Error('知识纠正仅在本机处理。');
      const value=await sendCloud(override.text,signal,priority,()=>{
        const current=store.pending(id);
        if(store.get(id)?.closed!==null||current.length!==ids.length||current.some((message,index)=>message.id!==ids[index]))
          throw Error('这条线有新进展，请重新预览');
      });
      if(value?.state==='answer'&&!value.askUser&&value.text?.trim())result={reply:value.text,next:'回应'};
      else throw Error('云端暂未取得回复');
    }else if(pending[0].handled){
      result=await command?.(id,pending[0],signal);
    }else{
      const quoted=await reference?.(id,pending,signal);
      if(quoted)result=quoted;
      else if(line.kind==='question'){
        const input=await context(id,pending,signal,settings);
        if(!input)return false;
        result=await activeQuestion?.(line,pending,{signal,priority:priority(),currentPriority:priority,context:input,
          isOpen:()=>store.get(id)?.closed===null,
          stillLatest:()=>store.get(id)?.closed===null&&store.pending(id).length===ids.length});
      }else{
        const input=await context(id,pending,signal,settings);
        signal.throwIfAborted();
        if(!input)return false;
        const before=store.detail(id,12)?.messages?.filter(item=>item.seq<pending[0].seq);
        const previous=before?.findLast(item=>item.who==='绯月');
        const knowledgeResults=[];
        for(const message of pending){
          const check=await knowledge?.inspect({text:message.text,source:'message/'+message.id,signal,direct:true,priority:priority(),
            context:{来源:input.来源,之前发言:input.之前发言.slice(-4)},previous:previous&&{id:previous.id,text:previous.text}});
          if(check)knowledgeResults.push({message:message.id,...check});
        }
        const use=knowledgeResults.find(check=>knowledgeReply(check))??knowledgeResults.find(check=>check.state==='apply');
        if(use&&pending.length===1)return store.finish(id,ids,use.answer,false,{knowledgePrivate:use.private,...(use.card?{knowledgeCard:use.card}:{})});
        const privateKnowledge=pending.some(message=>message.knowledgePrivate)||knowledgeResults.some(check=>check.private);
        const localOnly=Boolean(privateKnowledge||input.来源||input.较早历史||input.之前发言.length||pending.length!==1||pending[0].mode==='direct');
        try{
          if(!model?.memory&&model?.analyze&&pending[0].mode==='direct'){
            const raw=await model.analyze(pending[0].text,{hint:'direct',signal});
            if(raw?.reply)result={reply:raw.reply,next:'回应'};
          }else result=await modelCall(use?{...input,本机逐条核对:knowledgeResults.filter(check=>check.answer)
            .map(({message,answer,rules})=>({发言编号:message,回复依据:answer,规则:rules}))}:input,
          use?instruction+' 逐条处理最新发言，优先保留该发言对应的本机核对结论。':instruction,schema,signal,
          {...settings,aiPrivate:privateKnowledge});
          if(!result?.reply?.trim()||!nextStep.enum.includes(result.next))throw Error('本机回复格式无效');
        }catch(error){
          signal.throwIfAborted();
          void log?.({direction:'local',route:'对话线',stage:'本机回复未完成',turn_id:ids[0],error:error.code??error.name});
          if(localOnly||!cloud)throw Object.assign(Error('本机暂未答复，已保存原话。'),{canCloud:localOnly&&!privateKnowledge&&pending[0].mode!=='direct'});
          const value=await sendCloud(pending[0].text,signal,priority);
          if(value?.state!=='answer'||value.askUser||!value.text?.trim()){
            void log?.({direction:'local',route:'对话线',stage:'云端回复未完成',turn_id:ids[0],error:value?.code??'AI_UNAVAILABLE'});
            throw error;
          }
          result={reply:value.text,next:'回应'};
        }
        if(privateKnowledge)result.extra={...result.extra,knowledgePrivate:true};
      }
    }
    if(!result?.reply?.trim())throw Error('这组发言还没有取得回复');
    if(lifecycle.signal.aborted)return false;
    if(result.next==='结束'&&store.pending(id).length!==ids.length){
      if(line.kind==='question')return store.finish(id,ids,result.reply,false,result.extra);
      return true;
    }
    return store.finish(id,ids,result.reply,result.next==='结束',result.extra);
  }
  function run(id,{foreground=false,override}={}){
    clearTimeout(timers.get(id));timers.delete(id);
    if(lifecycle.signal.aborted)return null;
    if(runs.has(id))return runs.get(id);
    const line=store.get(id);
    if(!line?.pending||line.closed!==null||line.rounds>100)return null;
    const work=Promise.resolve().then(()=>answer(id,{foreground,override})).catch(error=>{
      if(!lifecycle.signal.aborted){
        store.fail(id,{text:error.message,canCloud:error.canCloud===true||Boolean(override)});
        void log?.({direction:'local',route:'对话线',stage:'回复等待重试',error:error.code??error.name});
      }
    }).then(result=>{
      runs.delete(id);
      if(lifecycle.signal.aborted)return;
      updated(id);
      if(result&&store.get(id)?.closed===null)schedule(id,engaged?.(id));
      return result;
    });
    runs.set(id,work);
    updated(id);
    return work;
  }
  function schedule(id,foreground=false){
    if(foreground)return run(id,{foreground});
    if(lifecycle.signal.aborted||runs.has(id)||timers.has(id))return;
    const timer=setTimeout(()=>run(id),650);
    timer.unref?.();
    timers.set(id,timer);
  }
  return {
    schedule,run,busy:id=>runs.has(id),get active(){return runs.size>0;},get activeCount(){return runs.size;},
    recover(){for(const {id} of store.recover())schedule(id);},
    preview(id,text){
      const line=store.get(id);
      if(!line?.error?.canCloud||line.closed!==null||line.rounds>=50||runs.has(id))throw Error('当前对话未在等待补充');
      text=typeof text==='string'?text.trim():'';
      if(!text||text.length>2000)throw Error('请输入 2000 字以内的独立问题');
      const preview={id:randomUUID(),text,ids:store.pending(id).map(message=>message.id)};
      previews.set(id,preview);
      return {id:preview.id,text};
    },
    confirm(id,key){
      const preview=previews.get(id);
      if(!preview||preview.id!==key||runs.has(id))throw Error('请重新预览外发文字');
      previews.delete(id);
      const pending=store.pending(id);
      if(pending.length!==preview.ids.length||pending.some((message,index)=>message.id!==preview.ids[index]))throw Error('这条线有新进展，请重新预览');
      return run(id,{foreground:true,override:preview});
    },
    dismissPreview:id=>previews.delete(id),
    settled:()=>Promise.allSettled(runs.values()),
    async close(){
      lifecycle.abort();
      for(const timer of timers.values())clearTimeout(timer);
      timers.clear();previews.clear();
      await Promise.allSettled(runs.values());
    },
  };
}
