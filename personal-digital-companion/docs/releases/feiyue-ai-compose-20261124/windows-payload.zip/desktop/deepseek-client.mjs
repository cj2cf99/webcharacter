const endpoint='https://api.deepseek.com/chat/completions';
let taskAudit;

export function setDeepSeekTaskAudit(audit){
  taskAudit=audit;
}

export function isDeepSeekConfigured(){
  return Boolean(process.env.DEEPSEEK_API_KEY?.trim());
}

function unavailable(code){
  return Object.assign(Error(code),{code});
}

export async function requestDeepSeek(payload,{signal,timeoutMs=30000,fetcher=fetch,key=process.env.DEEPSEEK_API_KEY,audit=taskAudit,purpose='模型调用'}={}){
  const secret=key?.trim();
  const scrub=value=>!secret||value===undefined?value:JSON.parse(JSON.stringify(value,(_key,entry)=>
    typeof entry==='string'?entry.replaceAll(secret,'[已隐藏 API 密钥]'):entry));
  let finish;
  try{
    finish=await audit?.({purpose,input:scrub(payload)});
  }catch{
    throw unavailable('DEEPSEEK_AUDIT_FAILED');
  }
  const start=performance.now();
  const deadline=AbortSignal.timeout(timeoutMs);
  const active=signal?AbortSignal.any([signal,deadline]):deadline;
  let status,output,errorCode;
  try{
    if(!secret)throw unavailable('DEEPSEEK_KEY_MISSING');
    active.throwIfAborted();
    let response,raw;
    try{
      response=await fetcher(endpoint,{
        method:'POST',redirect:'error',signal:active,
        headers:{authorization:'Bearer '+secret,'content-type':'application/json'},
        body:JSON.stringify(payload)
      });
      status=response.status;
      raw=await response.text();
    }catch{
      signal?.throwIfAborted();
      throw unavailable(deadline.aborted?'DEEPSEEK_TIMEOUT':'DEEPSEEK_UNAVAILABLE');
    }
    let body;
    try{body=JSON.parse(raw);}catch{/* 非 JSON 错误回执仍可在本地查看。 */}
    if(!response.ok){
      output=body?.error??body??raw;
      throw unavailable('DEEPSEEK_HTTP_'+status);
    }
    const choice=body?.choices?.[0];
    output=choice?{content:choice.message?.content,finishReason:choice.finish_reason,model:body.model,usage:body.usage}
      :body?.error??body??raw;
    active.throwIfAborted();
    if(typeof choice?.message?.content!=='string'||!choice.message.content.trim())throw Error();
    return {content:choice.message.content,finishReason:choice.finish_reason};
  }catch(error){
    errorCode=signal?.aborted?'DEEPSEEK_CANCELLED':deadline.aborted?'DEEPSEEK_TIMEOUT':
      typeof error.code==='string'?error.code:'DEEPSEEK_RESULT_INVALID';
    signal?.throwIfAborted();
    throw unavailable(errorCode);
  }finally{
    if(finish)try{
      await finish({output:scrub(output),error:errorCode,httpStatus:status,durationMs:Math.round(performance.now()-start)});
    }catch{
      throw unavailable('DEEPSEEK_AUDIT_FAILED');
    }
  }
}
